from django.urls import path, include
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('create_user', views.create_user, name='create_user'),
    path('login', views.login, name='login'),
    path('order_tickets', views.create_user, name='order_tickets'),

]

from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns += staticfiles_urlpatterns()

