from rest_framework import serializers
from .models import Users


class CreateUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = '__all__'

class GetUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ["username", "password"]
