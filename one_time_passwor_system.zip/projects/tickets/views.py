from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render
from rest_framework.decorators import api_view
from .serializers import CreateUserSerializer
from rest_framework.response import Response
from .models import Users


def index(request):
    return render(request, 'login/login_page.html')


def get_users(username):
    try:
        user_filter = Users.objects.filter(username=username)
        user = user_filter.get()
        return user
    except ObjectDoesNotExist:
        return None


@api_view(['POST'])
def create_user(create_user_request):
    serializer = CreateUserSerializer(data=create_user_request.data, partial=True)
    if serializer.is_valid():
        users = get_users(create_user_request.data["username"])
        if not users:
            serializer.save()
            return Response({"status": 200, "result": True, "message": "Account created successfully."})
        else:
            return Response({"status": 200, "result": False, "message": "This user name already exists."})
    else:
        return Response({"status": 200, "result": False, "message": "Account creation filed."})


@api_view(['POST'])
def login(login_request):
    username = login_request.data["username"]
    password = login_request.data["password"]
    user = get_users(username)
    invalid_response = Response({"status": 200, "result": False, "message": "Invalid username or password."})
    if user:
        if user.password == password:
            return render(login_request, 'tickets/get_tickets.html')
        else:
            return invalid_response
    else:
        return invalid_response
